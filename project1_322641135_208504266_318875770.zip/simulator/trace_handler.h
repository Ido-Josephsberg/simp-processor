#pragma once


void update_trace(Simulator* sim);
void write_trace_file_wrapper(Simulator* sim, output_paths* paths);