#pragma once
#include "macros.h"


void update_7seg(Simulator* sim);
void write_display7seg_file_wrapper(Simulator* sim, output_paths* paths);