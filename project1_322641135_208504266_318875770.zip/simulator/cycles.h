#pragma once

#include <stdio.h>
#include "simulator.h"

int write_cycles_file_wrapper(Simulator* sim, output_paths* paths);
