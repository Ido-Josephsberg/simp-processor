#pragma once

void update_hwregtrace(Simulator* sim);
void write_hwregtrace_file_wrapper(Simulator* sim, output_paths* paths);