#pragma once
#include "macros.h"

void update_leds(Simulator* sim);
int write_leds_file_wrapper(Simulator* sim, output_paths* paths);