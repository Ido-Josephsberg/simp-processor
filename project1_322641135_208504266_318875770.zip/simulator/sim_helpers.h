#pragma once
#include <stdio.h>
#include "simulator.h"


// temp function declerations - those functions need to move to thier own file.
