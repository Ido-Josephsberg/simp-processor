// TODO

// push

// open solution

// set Line line_array[assembly_line_count] = {0};		// array of lines structs corresponding to assembly lines
// ^ first need to extract assembly_line_count from input .asm file

// Line assembly_row_to_line() ----> parse assembly string to line structure ----> 

// dynamic dictionary for label_name : label_address pairs ----> to be set on the fist run

// .word implementation 

// .asm programs (sort, factorial, rectangle, disktest)

// finalize function:
// go over all lines in line_array and translate them to machine code (uppercase hexadecimal) and write to "memin.txt" file  